from fastapi_cors.main import CORS

__all__ = ["CORS"]
